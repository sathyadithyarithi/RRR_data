# RRR_image_detection > RRR_labelled_data_new
https://universe.roboflow.com/sathyait107/rrr_image_detection

Provided by a Roboflow user
License: CC BY 4.0

