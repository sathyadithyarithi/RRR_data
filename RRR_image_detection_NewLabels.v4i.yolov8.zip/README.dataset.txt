# RRR_image_detection > 2025-01-01 9:49pm
https://universe.roboflow.com/sathyait107/rrr_image_detection

Provided by a Roboflow user
License: CC BY 4.0

