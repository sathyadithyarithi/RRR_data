# RRR_image_detection > 2024-12-02 1:36am
https://universe.roboflow.com/sathyait107/rrr_image_detection

Provided by a Roboflow user
License: CC BY 4.0

